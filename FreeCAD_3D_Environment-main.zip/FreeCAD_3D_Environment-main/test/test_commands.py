import time
from PySide2.QtCore import QTimer
from PySide2.QtWidgets import QLabel, QWidget
from PySide2 import QtCore, QtGui
from PySide2.QtGui import QPainter, QColor, QPen
import math
from setup import setup_freecad_env
setup_freecad_env()

import socket
import threading
import FreeCAD
import FreeCADGui

class HandTrackingOverlay(QWidget):
    def __init__(self, parent=None):
        # Get FreeCAD main window
        self.main_window = FreeCADGui.getMainWindow()
        super().__init__(self.main_window)
        
        # Set window flags for overlay
        self.setWindowFlags(QtCore.Qt.Tool | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        
        # Match size to FreeCAD window
        self.setGeometry(self.main_window.geometry())
        
        self.finger_positions = {}
        
        # Semi-transparent background
        self.setStyleSheet("background-color: rgba(0, 0, 0, 10);")
        
        # Timer for updates
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update)
        self.update_timer.start(16)  # 60fps
        
        # Create labels for finger positions
        self.finger_labels = {}
        for i in range(5):
            label = QLabel(self.main_window)
            label.setStyleSheet(
                "QLabel { background-color: black; color: white; padding: 5px; border-radius: 5px; }"
            )
            label.setGeometry(10, 10 + i*40, 300, 30)
            label.show()
            self.finger_labels[i] = label
        
        self.show()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Draw finger positions
        for finger_id, pos in self.finger_positions.items():
            colors = {
                0: QColor(255, 0, 0),    # Red for thumb
                1: QColor(0, 255, 0),    # Green for index
                2: QColor(0, 0, 255),    # Blue for middle
                3: QColor(255, 255, 0),  # Yellow for ring
                4: QColor(255, 0, 255)   # Magenta for pinky
            }
            
            pen = QPen(colors.get(finger_id, QColor(255, 255, 255)))
            pen.setWidth(3)
            painter.setPen(pen)
            
            x, y = pos
            painter.drawEllipse(int(x)-5, int(y)-5, 10, 10)
            painter.drawText(int(x)+10, int(y)+10, f"F{finger_id}")

    def update_finger_position(self, finger_id, x, y):
        self.finger_positions[finger_id] = (x, y)
        # Update label text
        if finger_id in self.finger_labels:
            self.finger_labels[finger_id].setText(f"Finger {finger_id}: x={x:.1f}, y={y:.1f}")
        self.update()

    def moveEvent(self, event):
        """Keep overlay aligned with FreeCAD window"""
        if self.main_window:
            self.setGeometry(self.main_window.geometry())

class ServerConnect(QtCore.QObject):
    def __init__(self, process_data_callback, doc):
        super().__init__()
        self.doc = doc
        self.overlay = HandTrackingOverlay()
        # Create a default object
        self.create_default_object()
        
        self.setup_server()

    def create_default_object(self):
        """Create a default cube in the scene."""
        try:
            # Create a cube
            cube = self.doc.addObject("Part::Box", "DefaultCube")
            cube.Length = 50
            cube.Width = 50
            cube.Height = 50
            
            # Position it in view
            cube.Placement.Base = FreeCAD.Vector(-25, -25, -25)
            
            # Set visual properties
            cube.ViewObject.ShapeColor = (0.8, 0.2, 0.2)  # Red color
            
            self.doc.recompute()
            
            # Fit view to object
            FreeCADGui.SendMsgToActiveView("ViewFit")
            
        except Exception as e:
            print(f"Error creating default object: {e}")
            import traceback
            traceback.print_exc()

    def setup_server(self):
        """Initialize server for receiving tracking data."""
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.server.bind(('localhost', 12340))
            self.server.listen(1)
        except Exception as e:
            print(f"Server setup error: {e}")

    def process_server_data(self, data):
        """Process incoming tracking data."""
        try:
            if data.startswith("CAMERA:"):
                # Handle camera rotation
                rotations = data[7:].strip().split(",")
                yaw, pitch, roll = map(float, rotations)
                self._rotate_camera(yaw, pitch, roll)
            else:
                # Handle normal finger tracking
                finger_data_list = data.split(";")
                for finger_data in finger_data_list:
                    if not finger_data:
                        continue
                    parts = finger_data.split(",")
                    if len(parts) != 3:
                        continue
                    finger_id, x, y = map(float, parts)
                    self.overlay.update_finger_position(int(finger_id), x, y)
        except Exception as e:
            print(f"Error processing data: {e}")


    def _rotate_camera(self, yaw, pitch, roll):
        """Rotate camera using FreeCAD's direct view methods."""
        try:
            view = FreeCADGui.ActiveDocument.ActiveView
            
            # Scale the movements (smaller for smoother rotation)
            scale = 0.1
            
            if abs(yaw) > 0.1:
                # Use viewRotateLeft/Right for yaw
                if yaw > 0:
                    view.viewRotateLeft()
                else:
                    view.viewRotateRight()
                    
            if abs(pitch) > 0.1:
                # Use viewTop/Bottom for pitch
                current_dir = view.getViewDirection()
                new_dir = FreeCAD.Vector(current_dir.x, current_dir.y + pitch * scale, current_dir.z)
                view.setViewDirection(new_dir)
                
            view.redraw()
            
        except Exception as e:
            print(f"Error rotating camera: {e}")
            import traceback
            traceback.print_exc()

    def start_server(self):
        """Run the server loop."""
        print("Server starting...")
        while True:
            try:
                client, addr = self.server.accept()
                print(f"Connected: {addr}")
                while True:
                    data = client.recv(1024).decode('utf-8')
                    if not data:
                        break
                    self.process_server_data(data)
            except Exception as e:
                print(f"Server error: {e}")
            finally:
                if 'client' in locals():
                    client.close()

    def run_server_in_thread(self):
        """Start server in background thread."""
        server_thread = threading.Thread(target=self.start_server, daemon=True)
        server_thread.start()
        print("Server thread started")