import socket
import cv2
import mediapipe as mp
import time
import sys

# Initialize MediaPipe hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands()
mp_draw = mp.solutions.drawing_utils

def connect_with_retry(client, server_address, max_attempts=5):
    """Attempt to connect to server with retries."""
    attempt = 0
    while attempt < max_attempts:
        try:
            print(f"Attempting to connect to server (attempt {attempt + 1}/{max_attempts})...")
            client.connect(server_address)
            print("Connected successfully!")
            return True
        except ConnectionRefusedError:
            attempt += 1
            if attempt < max_attempts:
                print("Connection refused. Retrying in 2 seconds...")
                time.sleep(2)
            else:
                print("Could not connect to server after maximum attempts")
                return False
        except Exception as e:
            print(f"Unexpected error while connecting: {e}")
            return False
    return False

def format_coordinates(hand_landmarks, frame_shape):
    """matrix format: finger_id,x,y;finger_id,x,y;..."""
    finger_coords = []

    # Finger tips we want to track
    fingers = [
        mp_hands.HandLandmark.THUMB_TIP,
        mp_hands.HandLandmark.INDEX_FINGER_TIP,
        mp_hands.HandLandmark.MIDDLE_FINGER_TIP,
        mp_hands.HandLandmark.RING_FINGER_TIP,
        mp_hands.HandLandmark.PINKY_TIP
    ]

    # Get coordinates for each finger
    for finger_id, landmark_id in enumerate(fingers):
        landmark = hand_landmarks.landmark[landmark_id]
        x = int(landmark.x * frame_shape[1])
        y = int(landmark.y * frame_shape[0])

        # Only add if coordinates are within frame
        if 0 <= x < frame_shape[1] and 0 <= y < frame_shape[0]:
            finger_coords.append(f"{finger_id},{x},{y}")

    return ";".join(finger_coords) + "\n"

def main():
    # Set up the socket
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('localhost', 12340)

    # Try to connect to server
    if not connect_with_retry(client, server_address):
        print("Failed to connect to server. Please ensure FreeCAD is running.")
        return

    # Open webcam
    cap = cv2.VideoCapture(0)
    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    print(f"Default resolution: {int(width)}x{int(height)}")

    try:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Flip and convert frame to RGB
            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    # Draw landmarks
                    mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                    # Format and send coordinates
                    coord_str = format_coordinates(hand_landmarks, frame.shape)
                    try:
                        client.send(coord_str.encode('utf-8'))
                        print(f"Sent: {coord_str.strip()}")
                    except socket.error as e:
                        print(f"Socket error: {e}")
                        return

            # Display frame
            cv2.imshow("Hand Tracking", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    except KeyboardInterrupt:
        print("\nStopping hand tracking...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        print("Cleaning up...")
        cap.release()
        client.close()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()