import socket
import cv2
import mediapipe as mp
import time
import sys
import numpy as np
import math

# Initialize MediaPipe hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands()
mp_draw = mp.solutions.drawing_utils
class HandGestureDetector:
    def __init__(self):
        self.is_fist = False
        self.last_palm_position = None
        self.palm_landmarks = [0, 1, 5, 9, 13, 17]  # Wrist and finger bases
        
        # For smoothing
        self.smoothing_factor = 0.3
        self.last_rotations = [0, 0, 0]  # yaw, pitch, roll
        self.movement_threshold = 0.005  # Minimum movement to trigger rotation
        # New attribute
        self.last_timestamp = None

    def detect_fist(self, hand_landmarks):
        """More reliable fist detection."""
        finger_tips = [
            (mp_hands.HandLandmark.THUMB_TIP, mp_hands.HandLandmark.THUMB_IP),
            (mp_hands.HandLandmark.INDEX_FINGER_TIP, mp_hands.HandLandmark.INDEX_FINGER_PIP),
            (mp_hands.HandLandmark.MIDDLE_FINGER_TIP, mp_hands.HandLandmark.MIDDLE_FINGER_PIP),
            (mp_hands.HandLandmark.RING_FINGER_TIP, mp_hands.HandLandmark.RING_FINGER_PIP),
            (mp_hands.HandLandmark.PINKY_TIP, mp_hands.HandLandmark.PINKY_PIP)
        ]
        
        # Count curled fingers
        curled_fingers = 0
        for tip, pip in finger_tips:
            tip_pos = hand_landmarks.landmark[tip]
            pip_pos = hand_landmarks.landmark[pip]
            
            # A finger is curled if tip is lower than PIP joint
            if tip_pos.y > pip_pos.y:
                curled_fingers += 1
        
        # Consider it a fist if at least 4 fingers are curled
        return curled_fingers >= 4
    
    def calculate_palm_orientation(self, hand_landmarks, timestamp):
        if not self.is_fist:
            return None, None, None
            
        # Calculate palm center and orientation
        palm_points = [hand_landmarks.landmark[i] for i in self.palm_landmarks]
        palm_center = np.mean([[p.x, p.y, p.z] for p in palm_points], axis=0)
        
        if self.last_palm_position is None:
            self.last_palm_position = palm_center
            return 0, 0, 0
        
        # Calculate normalized movement vectors
        dx = palm_center[0] - self.last_palm_position[0]
        dy = palm_center[1] - self.last_palm_position[1]
        
        # Only use z for coarse depth change detection
        dz = palm_center[2] - self.last_palm_position[2]
        
        # Apply movement threshold to reduce jitter
        dx = 0 if abs(dx) < self.movement_threshold else dx
        dy = 0 if abs(dy) < self.movement_threshold else dy
        dz = 0 if abs(dz) < self.movement_threshold else dz
        
        # Scale factors - adjust these to change sensitivity
        yaw_scale = 2
        pitch_scale = 2
        roll_scale = 1
        
        # Calculate rotations
        yaw = dx * yaw_scale
        pitch = -dy * pitch_scale  # Invert for intuitive up/down
        roll = dz * roll_scale
        
        # Apply timestamp-based smoothing
        time_delta = timestamp - self.last_timestamp
        self.last_timestamp = timestamp

        # Adjust the rotation values based on the time delta
        yaw = self.smooth_rotation(yaw, 0, time_delta)
        pitch = self.smooth_rotation(pitch, 1, time_delta)
        roll = self.smooth_rotation(roll, 2, time_delta)

        self.last_palm_position = palm_center
        return yaw, pitch, roll

    def smooth_rotation(self, new_value, index, time_delta):
        """Apply adaptive exponential smoothing to rotation values."""
        if self.last_rotations[index] is None:
            self.last_rotations[index] = new_value
            return new_value

        # Calculate the rate of change in the rotation value
        rate_of_change = abs(new_value - self.last_rotations[index])

        # Adjust the smoothing factor based on the rate of change
        
        smoothing_factor = 0.5

        # Apply the smoothing based on the time delta
        smoothed = (smoothing_factor * new_value  + 
                (1 - smoothing_factor) * self.last_rotations[index])
        self.last_rotations[index] = smoothed
        return smoothed

def connect_with_retry(client, server_address, max_attempts=5):
    """Attempt to connect to server with retries."""
    attempt = 0
    while attempt < max_attempts:
        try:
            print(f"Attempting to connect to server (attempt {attempt + 1}/{max_attempts})...")
            client.connect(server_address)
            print("Connected successfully!")
            return True
        except ConnectionRefusedError:
            attempt += 1
            if attempt < max_attempts:
                print("Connection refused. Retrying in 2 seconds...")
                time.sleep(2)
            else:
                print("Could not connect to server after maximum attempts")
                return False
        except Exception as e:
            print(f"Unexpected error while connecting: {e}")
            return False
    return False

def format_coordinates(hand_landmarks, frame_shape):
    """matrix format: finger_id,x,y;finger_id,x,y;..."""
    finger_coords = []

    # Finger tips we want to track
    fingers = [
        mp_hands.HandLandmark.THUMB_TIP,
        mp_hands.HandLandmark.INDEX_FINGER_TIP,
        mp_hands.HandLandmark.MIDDLE_FINGER_TIP,
        mp_hands.HandLandmark.RING_FINGER_TIP,
        mp_hands.HandLandmark.PINKY_TIP
    ]

    # Get coordinates for each finger
    for finger_id, landmark_id in enumerate(fingers):
        landmark = hand_landmarks.landmark[landmark_id]
        x = int(landmark.x * frame_shape[1])
        y = int(landmark.y * frame_shape[0])

        # Only add if coordinates are within frame
        if 0 <= x < frame_shape[1] and 0 <= y < frame_shape[0]:
            finger_coords.append(f"{finger_id},{x},{y}")

    return ";".join(finger_coords) + "\n"

def main():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('localhost', 12340)
    gesture_detector = HandGestureDetector()
    gesture_detector.last_timestamp = time.time()

    if not connect_with_retry(client, server_address):
        print("Failed to connect to server. Please ensure FreeCAD is running.")
        return

    cap = cv2.VideoCapture(0)
    print(f"Default resolution: {int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))}x{int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}")

    try:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                    
                    # Check for fist gesture
                    gesture_detector.is_fist = gesture_detector.detect_fist(hand_landmarks)
                    
                    if gesture_detector.is_fist:
                        # Calculate camera rotations
                        yaw, pitch, roll = gesture_detector.calculate_palm_orientation(hand_landmarks, time.time())
                        if yaw is not None:
                            # Send camera rotation command
                            rotation_cmd = f"CAMERA:{yaw:.2f},{pitch:.2f},{roll:.2f}\n"
                            client.send(rotation_cmd.encode('utf-8'))
                    else:
                        # Normal finger tracking
                        coord_str = format_coordinates(hand_landmarks, frame.shape)
                        client.send(coord_str.encode('utf-8'))
                        print(f"Sent: {coord_str.strip()}")

            # Add gesture status to frame
            status = "FIST" if gesture_detector.is_fist else "TRACKING"
            cv2.putText(frame, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            cv2.imshow("Hand Tracking", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    except KeyboardInterrupt:
        print("\nStopping hand tracking...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        print("Cleaning up...")
        cap.release()
        client.close()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()